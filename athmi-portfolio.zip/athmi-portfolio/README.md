# Athmi S Sathish — Portfolio

A responsive, terminal-inspired personal portfolio built with plain HTML, CSS and JavaScript.

## Included sections

- Hero introduction with terminal-style profile card
- About and quick facts
- Skills & tools
- Education timeline
- Languages
- Contact information

No framework, build command, npm packages or external JavaScript libraries are required.

## Run locally

Open `index.html` directly in a browser, or run a simple local server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy

### Netlify
1. Extract the ZIP.
2. Open Netlify and choose **Add new site → Deploy manually**.
3. Drag the extracted project folder into the deploy area.

### Vercel
1. Extract the ZIP and upload the folder to a GitHub repository.
2. Import the repository into Vercel.
3. Choose **Other** as the framework preset if prompted.
4. Leave the build command empty and set the output directory to `.`.

### Cloudflare Pages
1. Upload the project to a GitHub repository.
2. Create a Pages project and connect the repository.
3. Leave the build command empty and set the build output directory to `.`.

## Personal details to verify before publishing

The reference page supplied for this build displayed the following contact details, which have been carried over:
- Email: `athmisathish6@gmail.com`
- Phone: `+91 63624 90199`
- Location: `Bengaluru, India`

Please verify these are correct and that you want them publicly displayed before deployment.

The original reference's GitHub and LinkedIn buttons led to generic platform home pages rather than personal profile URLs, so they have not been added as misleading links. Add your actual profile URLs when ready.

## Editing content

Open `index.html` and search for the text you want to change. Main colors and typography are defined near the top of `styles.css` using CSS variables.
